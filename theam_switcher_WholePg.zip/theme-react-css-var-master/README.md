# theme-react-css-var

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/theme-react-css-var)